﻿namespace Book.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    using NUnit.Framework;
    [TestFixture]
    public class Tests
    {


        [Test]
        public void ConstructorShouldSetCorrectly()
        {
            var book = new Book("validBookName", "validAuthor");
            Assert.AreEqual("validBookName", book.BookName);
            Assert.AreEqual("validAuthor", book.Author);
        }

        [Test]
        public void BookNameAndBookAuthorShouldThrowAnException()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                var book = new Book(null, "validAuthor");
            }, "Invalid book name");
            Assert.Throws<ArgumentException>(() =>
            {
                var book = new Book("validBookName", null);
            }, "Invalid author");
        }
        [Test]
        public void AddMethodShouldThrowAnException()
        {
            var book = new Book("validBookName", "validAuthor");
            book.AddFootnote(1, "Text1");
            Assert.Throws<InvalidOperationException>(() =>
            {
                book.AddFootnote(1, "Text2");
            }, "Already exsist");
        }
        [Test]
        public void AddMethodShouldAddCorrectly()
        {
            var book = new Book("validBookName", "validAuthor");
            var type = book.GetType();
            FieldInfo field = type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic).First(x => x.Name == "footnote");
            Dictionary<int, string> dicc = new Dictionary<int, string>();
            dicc.Add(1, "Text1");
            book.AddFootnote(1, "Text1");
            CollectionAssert.AreEqual(dicc, (Dictionary<int, string>)field.GetValue(book));

        }
        [Test]
        public void FindMethodShouldThrowAnExceptionWhenElDoesNotExsist()
        {
            var book = new Book("validBookName", "validAuthor");
            Assert.Throws<InvalidOperationException>(() =>
            {
                book.FindFootnote(1);
            }, "Does not exsist");
        }
        [Test]
        public void FindMthodShouldReturnCorrectString()
        {
            var book = new Book("validBookName", "validAuthor");
            book.AddFootnote(1, "Text1");
            string output = $"Footnote #{1}: {"Text1"}";
            Assert.AreEqual(output, book.FindFootnote(1));

        }
        [Test]
        public void AlterMethodShouldThrowAnExceptionIfElDoesNotExsist()
        {
            var book = new Book("validBookName", "validAuthor");
            book.AddFootnote(1, "Text1");
            Assert.Throws<InvalidOperationException>(() =>
            {
                book.AlterFootnote(2, "Text2");
            }, "Footnote does not exists!" );
        }
        [Test]
        public void AltherMethodShouldChangeTheValue()
        {
            var book = new Book("validBookName", "validAuthor");
            var type = book.GetType();
            FieldInfo field = type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic).First(x => x.Name == "footnote");
            Dictionary<int, string> dicc = new Dictionary<int, string>();
            dicc.Add(1, "Text2");
            book.AddFootnote(1, "Text1");
            book.AlterFootnote(1, "Text2");
            CollectionAssert.AreEqual(dicc, (Dictionary<int, string>)field.GetValue(book));
        }
    }
}
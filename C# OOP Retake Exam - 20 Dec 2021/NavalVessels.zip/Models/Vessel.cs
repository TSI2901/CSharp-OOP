﻿using NavalVessels.Models.Contracts;
using NavalVessels.Utilities.Messages;
using System;
using System.Collections.Generic;

using System.Text;

namespace NavalVessels.Models
{
    public abstract class Vessel : IVessel
    {
        private string name;
        private ICaptain captain;
        private double armorThicknessToRepair;


       
        public Vessel(string name, double mainWeaponCaliber, double speed, double armorThickness)
        {
            Name = name;
            MainWeaponCaliber = mainWeaponCaliber;
            Speed = speed;
            ArmorThickness = armorThickness;

            armorThicknessToRepair = armorThickness;
            Targets = new List<string>();
        }
        public string Name
        {
            get { return name; }
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.InvalidVesselName);
                }
                name = value;
            }
        }

        public ICaptain Captain
        {
            get { return captain; }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException(ExceptionMessages.InvalidCaptainToVessel);
                }
                captain = value;
            }
        }
        public double ArmorThickness { get; set; }

        public double MainWeaponCaliber { get; set; }

        public double Speed { get; set; }

        public ICollection<string> Targets { get;  }

        public void Attack(IVessel target)
        {
            if (target == null)
            {
                throw new NullReferenceException(ExceptionMessages.InvalidTarget);
            }
            target.ArmorThickness -= MainWeaponCaliber;
            
            if (target.ArmorThickness < 0)
            {
                target.ArmorThickness = 0;
            }
            
            Targets.Add(target.Name);
        }

        public void RepairVessel()
        {
            if (ArmorThickness < armorThicknessToRepair)
            {
                
                this.ArmorThickness = armorThicknessToRepair;
            }
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            string targetsOutput = this.Targets.Count > 0 ? String.Join(", ", Targets) : "None";
            stringBuilder.AppendLine($"- {this.Name}");
            stringBuilder.AppendLine($" *Type: {this.GetType().Name}");
            stringBuilder.AppendLine($" *Armor thickness: {this.ArmorThickness}");
            stringBuilder.AppendLine($" *Main weapon caliber: {this.MainWeaponCaliber}");
            stringBuilder.AppendLine($" *Speed: {this.Speed} knots");
            if (this.Targets.Count > 0)
            {
                stringBuilder.AppendLine($" *Targets: {string.Join(", ", this.Targets)}");
            }
            else
            {
                stringBuilder.AppendLine($" *Targets: None");
            }
            return stringBuilder.ToString().TrimEnd();
        }
    }
}

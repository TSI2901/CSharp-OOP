﻿using NavalVessels.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace NavalVessels.Models
{
    public class Battleship : Vessel, IBattleship
    {
        private const double armourThickness = 300;

        public Battleship(string name, double mainWeaponCaliber, double speed) :base( name,  mainWeaponCaliber, speed, armourThickness) { }

        public bool SonarMode { get; private set; } = false;

        public void ToggleSonarMode()
        {
            if (SonarMode == false)
            {
                SonarMode = true;
                this.MainWeaponCaliber += 40;
                this.Speed -= 5;
            }
            else
            {
                SonarMode = false;
                this.MainWeaponCaliber -= 40;
                this.Speed += 5;
            }
        }

        public override string ToString()
        {
            var sonarInfo = string.Empty;
            if (this.SonarMode == true)
            {
                sonarInfo = "ON";
            }
            else
            {
                sonarInfo = "OFF";
            }
            return base.ToString() + Environment.NewLine + $" *Sonar mode: {sonarInfo}";
        }
    }
}

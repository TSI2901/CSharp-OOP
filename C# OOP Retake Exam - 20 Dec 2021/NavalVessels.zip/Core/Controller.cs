﻿using NavalVessels.Core.Contracts;
using NavalVessels.Models;
using NavalVessels.Repositories;
using System;
using NavalVessels.Models.Contracts;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using NavalVessels.Utilities.Messages;

namespace NavalVessels.Core
{
    public class Controller : IController
    {
        private readonly VesselRepository vessels;
        private readonly ICollection<ICaptain> captains;

        public Controller()
        {
            vessels = new VesselRepository();
            captains = new List<ICaptain>();
        }

        public string HireCaptain(string fullName)
        {
            string outPut;
            var currCap = new Captain(fullName);
            if (captains.Contains(currCap))
            {
                return String.Format(OutputMessages.CaptainIsAlreadyHired,fullName);
            }
            captains.Add(currCap);
            return String.Format(OutputMessages.SuccessfullyAddedCaptain,fullName);
        }
        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
        {
            IVessel currVessel = null;
            if (vesselType == "Submarine")
            {
                currVessel = new Submarine(name, mainWeaponCaliber, speed);
                if (vessels.FindByName(name) != null)
                {
                    return String.Format(OutputMessages.VesselIsAlreadyManufactured, currVessel.GetType().Name, name);
                }
                vessels.Add(currVessel);
                return String.Format(OutputMessages.SuccessfullyCreateVessel, currVessel.GetType().Name, name, mainWeaponCaliber, speed);
            }
            else if (vesselType == "Battleship")
            {
                currVessel = new Battleship(name, mainWeaponCaliber, speed);
                if (vessels.FindByName(name) != null)
                {
                    return String.Format(OutputMessages.VesselIsAlreadyManufactured, currVessel.GetType().Name, name);
                }
                vessels.Add(currVessel);
                return String.Format(OutputMessages.SuccessfullyCreateVessel, currVessel.GetType().Name, name, mainWeaponCaliber, speed);
            }
            else
            {
                return String.Format(OutputMessages.InvalidVesselType);
            }
        }
        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
        {
            if (!this.captains.Any(x => x.FullName == selectedCaptainName))
            {
                return String.Format(OutputMessages.CaptainNotFound, selectedCaptainName);
            }

            if (!this.vessels.Models.Any(x => x.Name == selectedVesselName))
            {
                return String.Format(OutputMessages.VesselNotFound, selectedVesselName);
            }
            var Currvessel = vessels.FindByName(selectedVesselName);
            if (Currvessel.Captain != null)
            {
                return String.Format(OutputMessages.VesselOccupied, selectedVesselName);
            }
            Currvessel.Captain = captains.FirstOrDefault(x => x.FullName == selectedCaptainName);
            var Currcaptain = captains.FirstOrDefault(x => x.FullName == selectedCaptainName);
            Currcaptain.AddVessel(Currvessel);
            return String.Format(OutputMessages.SuccessfullyAssignCaptain,selectedCaptainName, selectedVesselName);
        }

        public string AttackVessels(string attackingVesselName, string defendingVesselName)
        {
            var attackerVessele = this.vessels.Models.FirstOrDefault(x => x.Name == attackingVesselName);
            var defendingVessele = this.vessels.Models.FirstOrDefault(x => x.Name == defendingVesselName);
            if (attackerVessele == null
                || defendingVessele == null)
            {
                return $"Vessel {attackingVesselName} could not be found.";
            }

            if (attackerVessele.ArmorThickness == 0
                || defendingVessele.ArmorThickness == 0)
            {
                return $"Unarmored vessel {attackingVesselName} cannot attack or be attacked.";
            }

            attackerVessele.Attack(defendingVessele);
            attackerVessele.Captain.IncreaseCombatExperience();
            defendingVessele.Captain.IncreaseCombatExperience();
            return $"Vessel {defendingVesselName} was attacked by vessel {attackingVesselName} - current armor thickness: {defendingVessele.ArmorThickness}.";
        }
        public string CaptainReport(string captainFullName)
        {
            var currCap = captains.FirstOrDefault(x => x.FullName == captainFullName);
            return currCap.Report();
        }

        public string ServiceVessel(string vesselName)
        {
            var currVessel = vessels.FindByName(vesselName);
            if (currVessel != null)
            {
                currVessel.RepairVessel();
                return String.Format(OutputMessages.SuccessfullyRepairVessel, vesselName);
            }
            return String.Format(OutputMessages.VesselNotFound, vesselName);
        }

        public string ToggleSpecialMode(string vesselName)
        {
            var currVessel = vessels.FindByName(vesselName);
            if (currVessel != null)
            {
                if (currVessel.GetType().Name == "Battleship")
                {
                    var battleShip = (Battleship)currVessel;
                    battleShip.ToggleSonarMode();
                    return String.Format(OutputMessages.ToggleBattleshipSonarMode);
                }
                else if (currVessel.GetType().Name == "Submarine")
                {
                    var subMarine = (Submarine)currVessel;
                    subMarine.ToggleSubmergeMode();
                    return String.Format(OutputMessages.ToggleSubmarineSubmergeMode);
                }
            }
            return String.Format(OutputMessages.VesselNotFound, vesselName);
        }

        public string VesselReport(string vesselName)
        {
            return vessels.FindByName(vesselName).ToString();
        }
    }

        
    
}

﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Rectangle : Shape
    {
        private double height;
        private double width;
        public double Height 
        {
            get { return height; }
            set { height = value; }
        }
        public double Width
        {
            get { return width; }
            set { width = value; }
        }

        public Rectangle(double height, double width)
        {
            Height = height;
            Width = width;
        }

        public override double CalculateArea()
        {
            return height * width;
        }

        public override double CalculatePerimeter()
        {
            return (2 * width) + (2 * height);
        }

        public override string Draw()
        {
            StringBuilder sb = new StringBuilder();

            DrawLine('*', '*');

            for (int i = 0; i < height - 2; i++)
            {
                DrawLine('*', ' ');
            }

            DrawLine('*', '*');

            void DrawLine(char borderSymbol, char innerSymbol)
            {
                sb.Append(borderSymbol);
                

                for (int i = 0; i < width - 2; i++)
                {
                    sb.Append(innerSymbol);
                    
                }

                sb.AppendLine(borderSymbol.ToString());
                
            }

            return sb.ToString().TrimEnd();
        }
    }
}


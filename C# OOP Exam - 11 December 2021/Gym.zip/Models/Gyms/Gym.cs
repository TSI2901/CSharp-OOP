﻿using Gym.Models.Athletes.Contracts;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using Gym.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Gyms
{
    public abstract class Gym : IGym
    {
        private string name;
        

        private ICollection<IEquipment> equipment;
        private ICollection<IAthlete> athletes;

        public Gym(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;

            this.Equipment = new List<IEquipment>();
            this.Athletes = new List<IAthlete>();
        }
        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidGymName));
                }
                name = value;
            }
        }

        public int Capacity {get; set; }

        public double EquipmentWeight
        {
            get
            {
                double sum = 0;
                foreach (var item in Equipment)
                {
                    sum += item.Weight;
                }
                return sum;
            }
            
        }

        public ICollection<IEquipment> Equipment
        {
            get
            {
                return this.equipment;
            }
            private set
            {
                this.equipment = value;
            }
        }

        public ICollection<IAthlete> Athletes
        {
            get
            {
                return this.athletes;
            }
            private set
            {
                this.athletes = value;
            }
        }

        public void AddAthlete(IAthlete athlete)
        {
            if (this.Capacity == Athletes.Count)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.NotEnoughSize));
            }
            athletes.Add(athlete);
        }

        public void AddEquipment(IEquipment equipment)
        {
            this.Equipment.Add(equipment);
        }

        public void Exercise()
        {
            foreach (var item in Athletes)
            {
                item.Exercise();
            }
        }

        public string GymInfo()
        {
            var sb = new StringBuilder();
            List<string> list = new List<string>();
            foreach (var item in Athletes)
            {
                list.Add(item.FullName);
            }
            sb.AppendLine($"{this.Name} is a {this.GetType().Name}:");
            if (this.athletes.Count < 1)
            {
                sb.AppendLine("Athletes: No athletes");
            }
            else
            {
                sb.AppendLine($"Athletes: {String.Join(", ", list)}");
            }
            sb.AppendLine($"Equipment total count: {this.equipment.Count}");
            sb.AppendLine($"Equipment total weight: {this.EquipmentWeight} grams");
            return sb.ToString().Trim();
        }

        public bool RemoveAthlete(IAthlete athlete)
        {
            return this.Athletes.Remove(athlete);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public class Box
    {
        private double length;
        private double width;
        private double height;
        public double Length
        {
            get { return this.length; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Length)} cannot be zero or negative.");
                }
                this.length = value;
            }
        }
        public double Width 
        {
            get { return this.width; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Width)} cannot be zero or negative.");
                }
                this.width = value;
            }
        }
        public double Height
        {
            get { return this.height; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Height)} cannot be zero or negative.");
                }
                this.height = value;
            }
        }
        public Box(double length, double width,double height)
        {
            Length = length;
            Width = width;
            Height = height;
        }
        public double SurfaceArea()
        {
            double surfaceArea = ((Length * Width) * 2)
                + ((Length * Height) * 2) + ((Width * Height) * 2);

            return surfaceArea;
        }
        public double CalculateVolume()
        {
            double volume = Length * Width * Height;

            return volume;
        }
        public double CalculateLateralSurfaceArea()
        {
            double lateralSurfaceArea = ((Length * Height) * 2)
                + ((Width * Height) * 2);

            return lateralSurfaceArea;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main()
        {
            RandomList random = new RandomList();
            random.Add("1");
            random.Add("2");
            random.Add("3");
            random.Add("4");
            random.Add("5");
            Console.WriteLine(random.RandomString()); 
        }
    }
}

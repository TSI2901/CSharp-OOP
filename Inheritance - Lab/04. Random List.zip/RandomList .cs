﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomRandomList
{
    public class RandomList:List<string>
    {
        public string RandomString()
        {
            Random random = new Random();
            string removed = "";
            int n = random.Next(0,this.Count);
            removed = this[n];
            this.Remove(removed);
            return removed;
        }
    }
}

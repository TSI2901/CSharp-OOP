﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomStack
{
    public class StackOfStrings : Stack<string>
    {
        public bool IsEmpty()
        {
            if (this.Any())
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public void AddRange(Stack<string> stack)
        {
            foreach (var item in stack)
            {
                this.Push(item);
            }
        }
    }

}

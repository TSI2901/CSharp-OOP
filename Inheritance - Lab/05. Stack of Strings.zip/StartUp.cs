﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace CustomStack
{
    public class StartUp
    {
        static void Main()
        {
            Stack<string> ss = new Stack<string>(Console.ReadLine().Split(' '));
            StackOfStrings stackOfStrings = new StackOfStrings();
            stackOfStrings.Push("1");
            stackOfStrings.Push("2");
            stackOfStrings.Push("3");
            stackOfStrings.Push("4");
            stackOfStrings.Push("5");
            Console.WriteLine(stackOfStrings.IsEmpty());
            stackOfStrings.AddRange(ss);
            Console.WriteLine(String.Join(" ",stackOfStrings));
        }
    }
}

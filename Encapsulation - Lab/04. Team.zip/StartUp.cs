﻿using System;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}

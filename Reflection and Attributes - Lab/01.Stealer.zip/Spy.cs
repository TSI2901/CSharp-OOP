﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string name, params string[] arr)
        {
            StringBuilder stringBuilder = new StringBuilder();
            Type type = Type.GetType(name);
            Object classIstance = Activator.CreateInstance(type, new object[] { });
            FieldInfo[] fieldInfos = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);
            stringBuilder.AppendLine($"Class under investigation: {type}");
            foreach (FieldInfo fieldInfo in fieldInfos.Where(f => arr.Contains(f.Name)))
            {
                stringBuilder.AppendLine($"{fieldInfo.Name} = {fieldInfo.GetValue(classIstance)}");
            }
            return stringBuilder.ToString().Trim();
        }
    }
}

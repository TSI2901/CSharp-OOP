﻿using System;
using System.Collections.Generic;

namespace Raiding
{
    public class StartUp
    {
        private static int MonsterHealth;
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            List<string> names = new List<string>();
            List<string> types = new List<string>();
            for (int i = 0; i < n; i++)
            {
                string name = Console.ReadLine();
                string type = Console.ReadLine();
                if (IsExist(type))
                {
                    names.Add(name);
                    types.Add(type);
                }
                else
                {
                    Console.WriteLine("Invalid hero!");
                    i--;
                }
            }
            MonsterHealth = int.Parse(Console.ReadLine());
            for (int i = 0; i < names.Count; i++)
            {
                string currName = names[i];
                string currType = types[i];
                if (currType == "Druid")
                {
                    BaseHero hero = new Druid(currName);
                    DoDamage(hero);
                }
                else if (currType == "Paladin")
                {
                    BaseHero hero = new Paladin(currName);
                    DoDamage(hero);
                }
                else if (currType == "Rogue")
                {
                    BaseHero hero = new Rogue(currName);
                    DoDamage(hero);
                }
                else if (currType == "Warrior")
                {
                    BaseHero hero = new Warrior(currName);
                    DoDamage(hero);
                }
            }
            if (MonsterHealth <= 0)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }
        static bool IsExist(string type) 
        {
            if (type == "Druid")
            {
                return true;
            }
            else if (type == "Paladin")
            {
                return true;
            }
            else if (type == "Rogue")
            {
                return true;
            }
            else if (type == "Warrior")
            {
                return true;
            }
            return false;
        }
        static void DoDamage(BaseHero hero)
        {
            MonsterHealth -= hero.Power;
            Console.WriteLine(hero.CastAbility());
        }
    }
}

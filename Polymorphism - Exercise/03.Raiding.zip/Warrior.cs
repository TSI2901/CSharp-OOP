﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Warrior:BaseHero
    {
        public override int Power { get; set; } = 100;
        public Warrior(string name) : base(name) { }
        public override string CastAbility()
        {
            return $"Warrior - {Name} hit for {Power} damage";
        }
    }
}

namespace Database.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class DatabaseTests
    {
        private  Database db;
        [SetUp]
        public void SetUp()
        {
            this.db = new Database();
        }
        [TestCase(new int[] { })]
        [TestCase(new int[] {1 })]
        [TestCase(new int[] {1, 2, 3})]
        [TestCase(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16})]
        public void ConstructorShoudAddLessThan1Eel(int[] elementsToAdd)
        {
            Database testdb = new Database(elementsToAdd);
            int[] actualEl = testdb.Fetch();
            int[] expextedEl = elementsToAdd;
            
            int actualCount = testdb.Count;
            int expectedCount = expextedEl.Length;

            CollectionAssert.AreEqual(expextedEl, actualEl, "Constructor is correct");
            Assert.AreEqual(expectedCount, actualCount, "Count work!");
        }
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17})]
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20})]
        public void ConstructorShoudNotAddMoreThan16El(int[] elementsToAdd)
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                Database testdb = new Database(elementsToAdd);
            }, "Array's capacity must be exactly 16 integers!");
        }
        [Test]
        public void AddShouldThrowAnExeptionWhenCountIsOver16()
        {
            for (int i = 0; i < 16; i++)
            {
                this.db.Add(i);
            }
            Assert.Throws<InvalidOperationException>(() =>
            {
                this.db.Add(17);
            },"Data can't be more than 16 integers!" );
        }
        [Test]
        public void RemoveMustNotRemoveFromAnEmptyDataBase()
        {
            Assert.Throws<InvalidOperationException>(() =>
           {
               this.db.Remove();
           }, "Database should have more atleast one element!");
        }
        [TestCase(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 })]
        public void FetchShouldReturnCoryArray(int[] ToAdd)
        {
            Database testDb = new Database(ToAdd);
            
            int[] currArray = testDb.Fetch();
            int[] expectedArr = ToAdd;
            CollectionAssert.AreEqual(expectedArr, currArray, "Fetch should return copy of the array!");
        }
    }
}

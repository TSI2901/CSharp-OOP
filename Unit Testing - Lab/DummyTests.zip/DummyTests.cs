﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void Test1()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(dummy.Health, Is.EqualTo(0));
        }
        [Test]
        public void Test2()
        {
            Assert.That(() =>
            {

                var axe = new Axe(10, 10);
                var dummy = new Dummy(10, 10);
                axe.Attack(dummy);
                axe.Attack(dummy);
            },
             Throws.Exception.TypeOf<InvalidOperationException>(),
             "Dummy is dead.");
        }
        [Test]
        public void Test3()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(dummy.GiveExperience(), Is.EqualTo(10));
            
        }
        [Test]
        public void Test4()
        {
            Assert.That(() =>
            {
                Axe axe = new Axe(10, 10);
                Dummy dummy = new Dummy(10, 10);
                dummy.GiveExperience();

            }, Throws.Exception.TypeOf<InvalidOperationException>(),
            "Target is not dead.");
        }
    }
}